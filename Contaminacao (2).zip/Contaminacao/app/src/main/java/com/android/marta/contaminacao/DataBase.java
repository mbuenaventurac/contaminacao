package com.android.marta.contaminacao;

import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by julia on 14/10/2017.
 */

public class DataBase {

    private ArrayList<Sensor> sensors = new ArrayList<Sensor>();
    private ArrayList<Sensor> rank = new ArrayList<Sensor>();

    int i = 0;
    private URL URL_SENTILIO = new URL("https://api.thingtia.cloud");
    private String json;
    private JSONObject dades;



    public DataBase() throws MalformedURLException {
    }

    public Response obtenirLocalitzacions(String token, String sensor) throws IOException, JSONException {

        Request request = new Request.Builder()
                .url(URL_SENTILIO + "/data/Prov1/" + sensor)
                .get()
                .addHeader("IDENTITY_KEY", token)
                .addHeader("Content-Type", "application/json")
                .build();
        OkHttpClient client = new OkHttpClient();
        Log.e("test", "test");
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                if (!response.isSuccessful()) {
                    throw new IOException("Unexpected code " + response);
                } else {
                    json = (String) response.body().string();
                    try {
                        dades = new JSONObject(json);
                        //Log.d("response", response.body().string());
                        //resposta = response.body().string();
                        Log.d("ERR", json);


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

        });
        return null;
    }

}
