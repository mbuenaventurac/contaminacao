package com.android.marta.contaminacao;

/**
 * Created by julia on 14/10/2017.
 */

public class Sensor {
    private String nom;
    private int value;

    public Sensor(int v, String n){
        this.value = v;
        this.nom = n;
    }

    public int getValue(){
        return value;
    }

    public void setValue(int valor){
        this.value = valor;
    }
}
