package com.android.marta.contaminacao;

public class Sensor {
    private String nom;
    private double value;

    public Sensor(double v, String n){
        this.value = v;
        this.nom = n;
    }

    public double getValue(){
        return value;
    }

    public void setValue(double valor){
        this.value = valor;
    }

    public void setName(String n){
        this.nom = n;
    }

    public String getName(){
        return nom;
    }
}
