package com.android.marta.contaminacao;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.view.ActionMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Headers;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.util.Collections;

import static android.R.attr.value;

public class MainActivity extends AppCompatActivity {

    public MainActivity() throws MalformedURLException {
    }
    private EditText edit;
    Button click,rankingButton;
    public TextView data,resRank;
    String resposta;
    String json;
    JSONObject dades;
    DataBase db = new DataBase();
    String Prov1 = new String("67e75b27b341de55b114a3293321a733bec34e0274c8ba1edad7b10ab04e0968");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edit = (EditText) findViewById(R.id.ciutat);
        click = (Button) findViewById(R.id.veure);
        data = (TextView) findViewById(R.id.resultat);
        resRank = (TextView) findViewById(R.id.resRank);
        rankingButton = (Button) findViewById(R.id.ranking);

        click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String sensor = edit.getText().toString();
               // Log.d("d",sensor);
                Response response = null;
                // Viva las telecos

                try {
                    response = db.obtenirLocalitzacions(Prov1, sensor);
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    Log.d("e", e.toString());
                }
                //String merda_petita = db.getString();

                try {
                    data.setText(String.valueOf(db.getValor()));
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        });
        /*rankingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Response response = null;
                try {

                    response = db.obtenirLocalitzacions(Prov1, null);
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    Log.d("e", e.toString());
                }
                //String merda_petita = db.getString();

                try {
                    Iterator<String> itr = al.iterator();
                    while (itr.hasNext()) {
                        String element = itr.next();
                        System.out.print(element + " ");
                    resRank.setText(String.valueOf(db.getValor()));
                } catch (JSONException e) {
                    e.printStackTrace();
                }



            } catch (JSONException e) {
                    e.printStackTrace();
                }
            });
    }*/
    /*String[] cities = new String[];
                cities = {"Sensor6_BCN", "Bangkok", "Sensor4_BCN", "Sensor5_BCN", "Bruselles", "Rabat", "New York", "Bogota", "NovaDelhi", "Brasilia", "Ottawa", "Oslo", "Canberra", "Paris", "Praga", "Pretoria", "Sensor3_BCN", "Sensor2_BCN", "SanJose", "BuenosAires", "Roma", "Budapest", "Shangai", "Sensor1_BCN", "Tokio", "Hanoi", "London", "Athenas", "Sofia", "Kiev", "Vilna", "Moscow", "Sana", "Madrid", "Taillin", "Elcairo", "DCMexico", "Seul", "Dakar"};
    int i;

    public ArrayList<Sensor> tornarArray() throws IOException, JSONException {
        ArrayList<Sensor> s = new ArrayList<Sensor>();

        for(i=0; i < 40; i++) {
            Response res = db.obtenirLocalitzacions(Prov1, cities[i]);
            String valors = db.getString();
            double valor = db.getDouble(valors);
            Sensor sen = new Sensor(valor,cities[i]);
            s.add(sen);
        }

        return s;
    }
    public void Ranking() throws IOException, JSONException {
        ArrayList<Sensor> rank = new ArrayList<Sensor>(40);
        ArrayList<Sensor> sensors = tornarArray();

        Collections.sort(rank);


    }

    static class Sensor implements Comparable<Sensor> {

        public String nombre;
        public double valor;

        public Sensor(double valor, String nombre) {
            this.nombre = nombre;
            this.valor = valor;
        }

        @Override
        public int compareTo(Sensor o) {
            if (valor < o.valor) {
                return -1;
            }
            if (valor > o.valor) {
                return 1;
            }
            return 0;
        }*/
    }



    }


