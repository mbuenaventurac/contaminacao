package com.android.marta.contaminacao;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.view.ActionMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Headers;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    public MainActivity() throws MalformedURLException {
    }
    Button click;
    public static TextView data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        click = (Button) findViewById(R.id.button);
        data = (TextView) findViewById(R.id.data);

        click.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                String Prov1 = new String("67e75b27b341de55b114a3293321a733bec34e0274c8ba1edad7b10ab04e0968");
                Response response = null;

                try {
                    response = obtenirLocalitzacions(Prov1);
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    Log.d("e", e.toString());
                }
            }
        });
    }

    URL URL_SENTILIO = new URL("https://api.thingtia.cloud");

    public Response obtenirLocalitzacions(String token) throws IOException, JSONException {

        Request request = new Request.Builder()
                .url(URL_SENTILIO + "/data/Prov1")
                .get()
                .addHeader("IDENTITY_KEY", token)
                .addHeader("Content-Type", "application/json")
                .build();
        OkHttpClient client = new OkHttpClient();
        Log.e("test", "test");
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                Log.d("response", response.body().string());
            }
        });
        return null;
    }
}
